import os
import secrets
import uuid
from functools import wraps

from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

FLAG = os.environ.get("FLAG", "FLAG{dummy}")

# リバースプロキシ配下で動かす際の URL プレフィックス (例: "/idor/step2")
# 未設定または空文字ならプレフィックスなしで動作する
URL_BASE = (os.environ.get("URL_BASE") or "").strip().rstrip("/")
if URL_BASE and not URL_BASE.startswith("/"):
    URL_BASE = "/" + URL_BASE


class PrefixMiddleware:
    # SCRIPT_NAME にプレフィックスを設定し、url_for() が生成する URL に反映させる。
    # nginx がプレフィックスを除去して転送する場合 (proxy_pass http://.../;) はそのまま、
    # プレフィックス付きのまま届いた場合は PATH_INFO から取り除いてルーティングする。
    def __init__(self, wsgi_app, prefix):
        self.wsgi_app = wsgi_app
        self.prefix = prefix

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO", "")
        if path == self.prefix or path.startswith(self.prefix + "/"):
            path = path[len(self.prefix):]
        environ["SCRIPT_NAME"] = self.prefix
        environ["PATH_INFO"] = path or "/"
        return self.wsgi_app(environ, start_response)


app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config["SESSION_COOKIE_NAME"] = "lms_session"
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.json.ensure_ascii = False
if URL_BASE:
    app.config["APPLICATION_ROOT"] = URL_BASE
    # 同一ホスト上の他の問題とセッション Cookie が衝突しないようパスを限定する
    app.config["SESSION_COOKIE_PATH"] = URL_BASE
    app.wsgi_app = PrefixMiddleware(app.wsgi_app, URL_BASE)

DEPARTMENTS = {
    1: "機械工学科",
    2: "情報工学科",
    3: "電気電子工学科",
    4: "大学院 情報学専攻",
}

USERS = {
    "Guest": {"username": "Guest", "password": "guest", "dept_id": 2},
}


def _course(dept_id, name, teacher, room, schedule, units, notice):
    return {
        "id": str(uuid.uuid4()),
        "dept_id": dept_id,
        "name": name,
        "teacher": teacher,
        "room": room,
        "schedule": schedule,
        "units": units,
        "notice": notice,
    }


COURSES = [
    _course(2, "プログラミング基礎", "佐藤 健一", "情報棟 101", "月曜 1限",
            ["変数と型", "条件分岐と繰り返し", "関数", "配列と文字列"],
            "第3回は休講です。"),
    _course(2, "データ構造とアルゴリズム", "鈴木 美咲", "情報棟 203", "火曜 2限",
            ["計算量", "リストとスタック", "木構造", "ソートと探索"],
            "演習課題は来週までに提出してください。"),
    _course(2, "コンピュータネットワーク", "高橋 誠", "情報棟 305", "水曜 3限",
            ["OSI参照モデル", "IPとルーティング", "TCPとUDP", "HTTPとDNS"],
            "中間試験の範囲はTCPまでです。"),
    _course(1, "材料力学", "田中 浩二", "機械棟 102", "月曜 2限",
            ["応力とひずみ", "はりの曲げ", "ねじり"],
            "教科書の第2章を予習してください。"),
    _course(1, "熱力学", "伊藤 大輔", "機械棟 201", "木曜 1限",
            ["熱力学第一法則", "エントロピー", "サイクル"],
            "来週は小テストを行います。"),
    _course(1, "機械製図", "渡辺 直樹", "機械棟 実習室", "金曜 4限",
            ["投影図", "寸法記入", "組立図"],
            "製図用具を持参してください。"),
    _course(3, "電気回路", "山本 恵子", "電気棟 104", "火曜 1限",
            ["オームの法則", "交流回路", "共振"],
            "第5回の教室が変更になります。"),
    _course(3, "電子工学概論", "中村 隆", "電気棟 210", "木曜 3限",
            ["半導体の基礎", "ダイオード", "トランジスタ"],
            "レポートの提出期限は月末です。"),
    _course(4, "機械学習特論", "小林 理恵", "大学院棟 401", "水曜 5限",
            ["線形モデル", "ニューラルネットワーク", "評価と汎化"],
            "論文紹介の担当を決めます。"),
    _course(4, "情報セキュリティ特論（院生限定）", "加藤 晃", "大学院棟 502", "金曜 3限",
            ["暗号理論の基礎", "認証と認可", "Webアプリケーションの安全性"],
            "期末レポートの提出キーワード: " + FLAG),
]

COURSES_BY_ID = {c["id"]: c for c in COURSES}


def current_user():
    return USERS.get(session.get("username"))


def login_required(view):
    # ログイン必須ページ用のデコレータ
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapper


def api_login_required(view):
    # ログイン必須API用のデコレータ
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return jsonify({"error": "unauthorized"}), 401
        return view(*args, **kwargs)

    return wrapper


@app.context_processor
def inject_current_user():
    return {"me": current_user()}


@app.get("/")
def index():
    if current_user() is None:
        return redirect(url_for("login"))
    return redirect(url_for("courses"))


@app.get("/login")
def login():
    return render_template("login.html", error=None)


@app.post("/login")
def login_post():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    user = USERS.get(username)
    if user is not None and secrets.compare_digest(
        user["password"].encode(), password.encode()
    ):
        session.clear()
        session["username"] = user["username"]
        return redirect(url_for("courses"))
    return (
        render_template("login.html", error="ユーザ名またはパスワードが違います。"),
        401,
    )


@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/courses")
@login_required
def courses():
    return render_template("courses.html")


@app.get("/courses/<course_id>")
@login_required
def course_page(course_id):
    return render_template("course.html")


@app.get("/api/me")
@api_login_required
def api_me():
    user = current_user()
    return jsonify(
        {
            "username": user["username"],
            "dept_id": user["dept_id"],
            "dept_name": DEPARTMENTS[user["dept_id"]],
        }
    )


@app.get("/api/courses")
@api_login_required
def list_courses():
    return jsonify(
        [{"id": c["id"], "name": c["name"], "dept_id": c["dept_id"]} for c in COURSES]
    )


@app.get("/api/courses/<course_id>")
@api_login_required
def get_course(course_id):
    course = COURSES_BY_ID.get(course_id)
    if course is None:
        return jsonify({"error": "not found"}), 404
    return jsonify(course)
