(async () => {
  const [me, courses] = await Promise.all([
    fetch(URL_BASE + "/api/me").then((r) => r.json()),
    fetch(URL_BASE + "/api/courses").then((r) => r.json()),
  ]);
  const mine = courses.filter((c) => c.dept_id === me.dept_id);
  document.getElementById("heading").textContent =
    "あなたの履修講義一覧（" + me.dept_name + "）";
  const tbody = document.getElementById("course-list");
  for (const c of mine) {
    const tr = document.createElement("tr");
    const idTd = document.createElement("td");
    idTd.className = "id";
    idTd.textContent = c.id;
    const nameTd = document.createElement("td");
    const a = document.createElement("a");
    a.href = URL_BASE + "/courses/" + encodeURIComponent(c.id);
    a.textContent = c.name;
    nameTd.appendChild(a);
    tr.append(idTd, nameTd);
    tbody.appendChild(tr);
  }
})();
