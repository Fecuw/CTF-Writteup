(async () => {
  const id = location.pathname.split("/").pop();
  const res = await fetch(URL_BASE + "/api/courses/" + encodeURIComponent(id));
  if (!res.ok) {
    document.getElementById("error").hidden = false;
    return;
  }
  const c = await res.json();
  for (const key of ["name", "teacher", "room", "schedule", "notice"]) {
    document.getElementById(key).textContent = c[key];
  }
  const ol = document.getElementById("units");
  for (const u of c.units) {
    const li = document.createElement("li");
    li.textContent = u;
    ol.appendChild(li);
  }
  document.getElementById("course").hidden = false;
})();
