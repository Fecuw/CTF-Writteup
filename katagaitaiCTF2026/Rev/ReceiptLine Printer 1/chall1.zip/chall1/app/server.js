'use strict';

const path = require('path');
const express = require('express');
const render = require('./lib/render');

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_DOC_LENGTH = 4000;

app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Escape characters that have special meaning inside a ReceiptLine property.
const PROPERTY_ESCAPE_CHARS = /[\\|{};]/g;
const escapeForProperty = (value) => {
    return String(value).replace(PROPERTY_ESCAPE_CHARS, c => '\\' + c);
};

// Template variables available as ${NAME} in the document.
const variables = {
    LOGO: '{image:iVBORw0KGgoAAAANSUhEUgAAASwAAABYCAAAAABq0pXKAAAB4UlEQVR42u2cSZbDIAxEXX6+/5XV2+7Ej0FUOiL52sUDgU+pLMig41fEQbTiBAGwgAUsYAELWCAYj+vTBiR32SiURRoCC1gYvN1bq/UMZQELWMACFrCIj1sbxgsbRFmkIbCAtVPoxsvUPnRMn+6ev13B6e7CbkuNRnI9a2/+aehQ58T87fr7Qkq3lNVK98Q58txU4t3GrtHcaBc7stre6Zojpx3safB8U6QNS5OzrjXRyOJ9SW3OtncirLyyBJKcZyGs9q5DT1ixJsCw6TfMmTDU3mURVtwVz4sdlxHCSz7dKeFYUdYEThwrCYtHYVJZCGvK4F3cfNjdExgmZSGs6YU0MZKG4V0F+Z4c7meQDLBANZ6GOFbasxBWCxbCmoBFJU/p8CJYSCtfOjy72Xdu/p0H0sKz/hMW0urBor5KpiHS6sFCWkmDR1o9WEgrWTq8S1p1Jf1YwYecA456tFZ61lruKNzj2Hxriwp+xbPeY/GxJyyqhxlYVA9JzxJ5WNLgY09Y8SitWBtv2GiFeSZm2xvaVo6nn0Np4LrZ26Of9aMdMfesUXgWCdVL0rpFacFZvOrpqK7Vs9wBFrCABSyH1xdcxVf8exWhLNIQWASwvgVWAKv4srmwsmIDkoX2s1RedD8uZVjkBu525gAAAABJRU5ErkJggg==}',
    SHOP_NAME: 'Katagaitai CTF',
    SHOP_ADDR: '東京都千代田区大手町x-x-x',
    SHOP_PHONE: '03-1234-xxxx',
    QR_CODE: '{code:https://www.nri-secure.co.jp/;o:qrcode,6}',
    FLAG: escapeForProperty(process.env.FLAG),
};

// Replace ${NAME} placeholders with their values (unknown names become empty).
const VAR_PATTERN = /\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g;
const fillVariables = (doc, vars) => {
    return doc.replace(VAR_PATTERN, (_, key) => vars[key] ?? '');
};

// Reject the SVG if its text contains the flag.
const securityCheck = (svg) => {
    const matches = svg.match(/<text[^>]*>([\s\S]*?)<\/text>/g) || [];
    const text = matches
        .map(tag => tag.replace(/<[^>]+>/g, '').trim())
        .filter(t => t)
        .join('');

    return !text.includes('FLAG');
};

app.post('/render', async (req, res) => {
    try {
        const doc = req.body && req.body.doc;

        if (typeof doc !== 'string' || doc.length === 0) {
            return res.status(400).json({ error: 'doc (string) is required' });
        }
        if (doc.length > MAX_DOC_LENGTH) {
            return res.status(400).json({ error: `doc must be ${MAX_DOC_LENGTH} characters or fewer` });
        }

        const filledDoc = fillVariables(doc, variables);
        const svg = await render.toSvg(filledDoc);

        if (!securityCheck(svg)) {
            return res.status(400).json({ error: 'blocked: request rejected' });
        }

        const png = await render.toPng(svg);

        res.set('Content-Type', 'image/png');
        res.set('Cache-Control', 'no-store');
        return res.send(png);
    } catch (err) {
        return res.status(400).json({ error: 'failed to render document' });
    }
});

app.listen(PORT, () => {
    console.log(`receiptline-printer listening on :${PORT}`);
});
