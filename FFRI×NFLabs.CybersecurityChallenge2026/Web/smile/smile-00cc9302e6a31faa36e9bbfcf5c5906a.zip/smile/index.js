const express = require('express');
const ejs = require('ejs');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/static', express.static(path.join(__dirname, 'public')));

const layout = fs.readFileSync(path.join(__dirname, 'views', 'layout.html'), 'utf8');

function renderPage({ content, error }) {
  return layout
    .replace('{{CONTENT}}', content || '')
    .replace('{{ERROR}}', error ? `<div class="error"><strong>Oops!</strong><pre>${escapeHtml(error)}</pre></div>` : '');
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

const EMPTY_CARD = `
  <div class="card placeholder">
    <div class="card-avatar">?</div>
    <p class="card-hint">Write something about yourself and hit "Generate" to see your smile card.</p>
  </div>
`;

app.get('/', (req, res) => {
  res.send(renderPage({ content: EMPTY_CARD }));
});

// Smile Studio renders your bio directly into the card template.
app.post('/card', (req, res) => {
  const bio = req.body.bio || '';

  const cardTemplate = `
    <div class="card">
      <div class="card-avatar">:)</div>
      <p class="card-bio">${bio}</p>
      <span class="card-stamp">Smile Studio &mdash; generated just for you</span>
    </div>
  `;

  try {
    const rendered = ejs.render(cardTemplate);
    res.send(renderPage({ content: rendered }));
  } catch (err) {
    res.status(500).send(renderPage({ content: EMPTY_CARD, error: err.message }));
  }
});

app.listen(PORT, () => {
  console.log(`Smile Studio is running on port ${PORT}`);
});