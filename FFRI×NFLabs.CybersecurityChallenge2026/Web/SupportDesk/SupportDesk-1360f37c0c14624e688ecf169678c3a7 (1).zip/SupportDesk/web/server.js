'use strict';

require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const snapshot = require('./lib/snapshot');
const { merge } = require('./lib/merge');
const { capabilitiesOf } = require('./lib/capabilities');
const tasks = require('./lib/tasks');

const app = express();
const PORT = process.env.PORT || 3000;
const BOT_SESSION_COOKIE = 'supportdesk_bot';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('view options', {});
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'dev-secret',
    resave: false,
    saveUninitialized: false,
  })
);
app.get('/js/purify.js', (req, res) => {
  res.type('application/javascript');
  res.sendFile(require.resolve('dompurify/dist/purify.min.js'));
});
const STATUSES = ['open', 'pending', 'resolved', 'closed'];
const PRIORITIES = ['low', 'normal', 'high', 'urgent'];
const CATEGORIES = ['account', 'billing', 'technical', 'feedback', 'other'];
function inList(list, value) {
  return list.indexOf(value) !== -1;
}
function fmtDate(d) {
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return '';
  return dt.toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
}
let nextUserId = 1;
const users = [];
function addUser(username, password, role, options) {
  const user = {
    id: nextUserId++,
    username: String(username),
    password,
    role,
    interactive: Boolean(options && options.interactive),
  };
  users.push(user);
  return user;
}
addUser('admin', process.env.ADMIN_PASSWORD || 'admin', 'admin', { interactive: true });
addUser('operator', process.env.OPERATOR_PASSWORD || 'operator', 'operator');

let nextTicketId = 1;
const tickets = [];
function addTicket(author, title, description, meta) {
  const m = meta || {};
  const ticket = {
    id: nextTicketId++,
    author,
    title,
    description,
    status: inList(STATUSES, m.status) ? m.status : 'open',
    priority: inList(PRIORITIES, m.priority) ? m.priority : 'normal',
    category: inList(CATEGORIES, m.category) ? m.category : 'other',
    createdAt: new Date(),
  };
  tickets.push(ticket);
  return ticket;
}
addTicket(
  'operator',
  'Welcome to SupportDesk',
  '<b>Please describe your problem.</b> An operator will review your ticket shortly.',
  { status: 'open', priority: 'normal', category: 'account' }
);
let nextCommentId = 1;
const comments = [];
function addComment(ticketId, author, body) {
  const comment = {
    id: nextCommentId++,
    ticketId: Number(ticketId),
    author: String(author),
    body: String(body),
    createdAt: new Date(),
  };
  comments.push(comment);
  return comment;
}
function commentsFor(ticketId) {
  const id = Number(ticketId);
  return comments.filter((c) => c.ticketId === id);
}
const operatorSettings = { theme: 'light', notify: { email: true, slack: false } };
let appConfig = {
  siteName: 'SupportDesk',
  maintenance: false,
  retentionDays: 30,
  createdAt: new Date('2025-01-01T00:00:00Z'),
  usernamePattern: /^[a-z0-9_]+$/,
};

function findUser(username) {
  const name = String(username == null ? '' : username).trim().toLowerCase();
  return users.find((u) => u.username.toLowerCase() === name);
}
function findUserById(id) {
  return users.find((u) => u.id === id);
}
function hasCookie(req, name, value) {
  const raw = req.get('cookie') || '';
  return raw.split(';').some((part) => {
    const idx = part.indexOf('=');
    if (idx === -1) return false;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    return key === name && (value == null || val === value);
  });
}
app.use((req, res, next) => {
  req.user = req.session.userId ? findUserById(req.session.userId) : null;
  req.caps = capabilitiesOf(req.user);
  if (req.user && !req.session.csrf) {
    req.session.csrf = crypto.randomBytes(16).toString('hex');
  }
  res.locals.user = req.user;
  res.locals.role = req.user ? req.user.role : null;
  res.locals.caps = req.caps;
  res.locals.csrf = req.session.csrf || '';
  res.locals.fmtDate = fmtDate;
  next();
});

function requireLogin(req, res, next) {
  if (!req.user) return res.redirect('/login');
  next();
}

function requireOperator(req, res, next) {
  if (!req.user || req.caps.manageSettings !== true) {
    return res.status(403).render('error', { message: 'You do not have permission to perform this action.' });
  }
  next();
}
function requireInteractiveOperator(req, res, next) {
  if (hasCookie(req, BOT_SESSION_COOKIE)) {
    return res.status(403).render('error', { message: 'You do not have permission to perform this action.' });
  }
  if (!req.user || req.user.interactive !== true) {
    return res.status(403).render('error', { message: 'You do not have permission to perform this action.' });
  }
  next();
}
function requireStaff(req, res, next) {
  if (!req.user || req.caps.manageTickets !== true) {
    return res.status(403).render('error', { message: 'You do not have permission to perform this action.' });
  }
  next();
}
function requireCsrf(req, res, next) {
  const token = req.get('x-csrf-token') || (req.body && req.body._csrf);
  if (!token || token !== req.session.csrf) {
    return res.status(403).json({ ok: false, error: 'invalid csrf token' });
  }
  next();
}
function requireAdmin(req, res, next) {
  if (hasCookie(req, BOT_SESSION_COOKIE)) {
    return res.status(403).render('error', { message: 'You do not have permission to access this page.' });
  }
  if (!req.user || req.user.interactive !== true) {
    return res.status(403).render('error', { message: 'You do not have permission to access this page.' });
  }
  if (req.caps.configAdmin === true) return next();
  return res.status(403).render('error', { message: 'You do not have permission to access this page.' });
}
app.get('/', (req, res) => res.render('index'));
app.get('/help', (req, res) => res.render('help'));

app.get('/register', (req, res) => res.render('register', { error: null }));

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.render('register', { error: 'username and password are required' });
  }
  if (findUser(username)) {
    return res.render('register', { error: 'username already exists' });
  }
  const user = addUser(String(username), String(password), 'user');
  req.session.userId = user.id;
  res.redirect('/tickets');
});

app.get('/login', (req, res) => res.render('login', { error: null }));

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = findUser(username);
  if (!user || user.password !== password) {
    return res.status(401).render('login', { error: 'invalid credentials' });
  }
  if (user.username === 'operator' && user.interactive !== true) {
    res.cookie(BOT_SESSION_COOKIE, '1', { httpOnly: true, sameSite: 'lax' });
  }
  req.session.userId = user.id;
  res.redirect('/tickets');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

app.get('/profile', requireLogin, (req, res) => {
  res.render('profile', { me: req.user });
});
app.get('/tickets', requireLogin, (req, res) => {
  const isStaff = req.user.role === 'operator' || req.user.role === 'admin';
  let scoped = isStaff ? tickets : tickets.filter((t) => t.author === req.user.username);
  const status = req.query.status;
  if (inList(STATUSES, status)) {
    scoped = scoped.filter((t) => t.status === status);
  }
  res.render('tickets', {
    tickets: scoped.slice().reverse(),
    isStaff,
    statuses: STATUSES,
    priorities: PRIORITIES,
    categories: CATEGORIES,
    filterStatus: inList(STATUSES, status) ? status : '',
  });
});

app.post('/tickets', requireLogin, (req, res) => {
  const { title, description } = req.body;
  if (!title || !description) return res.redirect('/tickets');
  const ticket = addTicket(
    req.user.username,
    String(title).slice(0, 200),
    String(description).slice(0, 20000),
    { priority: req.body.priority, category: req.body.category }
  );
  res.redirect('/tickets/' + ticket.id);
});

app.get('/tickets/:id', requireLogin, (req, res) => {
  const ticket = tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).render('error', { message: 'ticket not found' });
  const isStaff = req.user.role === 'operator' || req.user.role === 'admin';
  if (!isStaff && ticket.author !== req.user.username) {
    return res.status(403).render('error', { message: 'you can only view your own tickets' });
  }
  const rawB64 = Buffer.from(ticket.description, 'utf8').toString('base64');
  res.render('ticket', {
    ticket,
    rawB64,
    comments: commentsFor(ticket.id),
    isStaff,
    statuses: STATUSES,
  });
});
app.post('/tickets/:id/comments', requireLogin, (req, res) => {
  const ticket = tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).render('error', { message: 'ticket not found' });
  const isStaff = req.user.role === 'operator' || req.user.role === 'admin';
  if (!isStaff && ticket.author !== req.user.username) {
    return res.status(403).render('error', { message: 'you can only comment on your own tickets' });
  }
  const body = req.body.body;
  if (typeof body === 'string' && body.trim()) {
    addComment(ticket.id, req.user.username, body.slice(0, 5000));
  }
  res.redirect('/tickets/' + ticket.id);
});
app.post('/tickets/:id/status', requireStaff, (req, res) => {
  const ticket = tickets.find((t) => t.id === Number(req.params.id));
  if (!ticket) return res.status(404).render('error', { message: 'ticket not found' });
  if (inList(STATUSES, req.body.status)) {
    ticket.status = req.body.status;
  }
  res.redirect('/tickets/' + ticket.id);
});
app.post('/operator/promote', requireOperator, requireCsrf, (req, res) => {
  const target = findUser(req.body.username);
  if (target && target.role === 'user') {
    target.role = 'operator';
    target.interactive = true;
    return res.json({ ok: true, username: target.username, role: target.role });
  }
  res.json({ ok: false });
});

app.get('/operator', requireOperator, (req, res) => {
  res.render('operator', { settings: operatorSettings });
});

// Reject known-risky property names in the submitted settings before merging.
const BLOCKED_SETTING_KEYS = [
  'view options', 'settings', 'escapeFunction', 'escape', 'client',
  'compileDebug', 'outputFunctionName', 'localsName', 'destructuredLocals',
  'root', 'includer', 'context',
  'NODE_OPTIONS', 'execArgv', 'shell', 'env', 'argv0', 'cmd', 'input',
  'stdio', 'contextExtensions', 'main',
];
function hasBlockedKey(node, depth) {
  if (!node || typeof node !== 'object' || depth > 20) return false;
  for (const key of Object.keys(node)) {
    if (BLOCKED_SETTING_KEYS.indexOf(key) !== -1) return true;
    if (hasBlockedKey(node[key], depth + 1)) return true;
  }
  return false;
}

app.post('/operator/settings', requireOperator, requireInteractiveOperator, requireCsrf, (req, res) => {
  if (hasBlockedKey(req.body, 0)) {
    return res.status(403).json({
      ok: false,
      error:
        'This code-execution shortcut is unintended and has been disabled for this ' +
        'challenge. Please look for the intended path.',
    });
  }
  merge(operatorSettings, req.body || {});
  res.json({ ok: true, settings: operatorSettings });
});
app.get('/admin', requireAdmin, (req, res) => {
  res.render('admin', { config: appConfig, backup: snapshot.serialize(appConfig) });
});

app.get('/admin/backup', requireAdmin, (req, res) => {
  res.type('text/plain').send(snapshot.serialize(appConfig));
});

app.post('/admin/restore', requireAdmin, (req, res) => {
  const data = req.body.data;
  if (typeof data !== 'string') {
    return res.status(400).json({ ok: false, error: 'data must be a snapshot string' });
  }
  let restored;
  try {
    restored = snapshot.unserialize(data);
  } catch (err) {
    return res.status(400).json({ ok: false, error: String(err.message || err) });
  }
  appConfig = Object.assign({}, appConfig, restored);
  res.json({ ok: true, restored: snapshot.serialize(appConfig) });
});
app.get('/admin/report', requireAdmin, (req, res) => {
  try {
    res.type('text/plain').send(tasks.renderReport(appConfig));
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err.message || err) });
  }
});

app.listen(PORT, () => {
  console.log(`SupportDesk listening on port ${PORT}`);
});
