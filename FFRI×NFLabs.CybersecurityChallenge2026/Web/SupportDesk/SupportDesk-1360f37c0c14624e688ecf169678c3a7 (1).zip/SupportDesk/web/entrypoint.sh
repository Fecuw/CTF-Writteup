#!/bin/sh
set -e

: "${FLAG:=flag_placeholder_not_set}"
printf '%s\n' "$FLAG" > /flag.txt
unset FLAG

exec node server.js
