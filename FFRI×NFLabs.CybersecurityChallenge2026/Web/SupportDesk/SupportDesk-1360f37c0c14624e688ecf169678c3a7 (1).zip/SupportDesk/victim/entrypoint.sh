#!/bin/sh
set -e

umask 077
cat > /root/.env <<EOF
BOT_TARGET=${BOT_TARGET:-http://web:3000}
OPERATOR_PASSWORD=${OPERATOR_PASSWORD}
EOF

exec cron -f
