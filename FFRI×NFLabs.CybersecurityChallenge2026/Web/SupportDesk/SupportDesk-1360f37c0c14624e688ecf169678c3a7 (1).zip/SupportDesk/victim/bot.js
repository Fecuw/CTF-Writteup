require('dotenv').config({ path: '/root/.env' });
const fs = require('fs');
const puppeteer = require('puppeteer');

const BASE = process.env.BOT_TARGET || 'http://web:3000';
const SEEN_PATH = process.env.SEEN_PATH || '/root/seen.json';

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function loadSeen() {
  try {
    const arr = JSON.parse(fs.readFileSync(SEEN_PATH, 'utf8'));
    return new Set(Array.isArray(arr) ? arr.map(String) : []);
  } catch (e) {
    return new Set();
  }
}

function saveSeen(seen) {
  try {
    fs.writeFileSync(SEEN_PATH, JSON.stringify(Array.from(seen)));
  } catch (e) {
  }
}

(async () => {
  const seen = loadSeen();
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });

  try {
    const page = await browser.newPage();

    await page.goto(`${BASE}/login`, { waitUntil: 'networkidle0' });
    await page.type('input[name="username"]', 'operator');
    await page.type('input[name="password"]', process.env.OPERATOR_PASSWORD);
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle0' }).catch(() => {}),
      page.click('button[type="submit"]'),
    ]);

    await page.goto(`${BASE}/tickets`, { waitUntil: 'networkidle0' });
    const ticketRefs = await page.evaluate(() =>
      Array.from(document.querySelectorAll('a[data-ticket-id]')).map((a) => ({
        id: a.getAttribute('data-ticket-id'),
        key: a.getAttribute('data-ticket-key') || a.getAttribute('data-ticket-id'),
      }))
    );
    for (const ticket of ticketRefs) {
      const id = String(ticket.id);
      const key = String(ticket.key || ticket.id);
      if (seen.has(key)) continue;
      try {
        await page.goto(`${BASE}/tickets/${id}`, { waitUntil: 'networkidle0' });
        await sleep(5000);
        seen.add(key);
      } catch (e) {
      }
    }
  } finally {
    await browser.close();
    saveSeen(seen);
  }
})();
