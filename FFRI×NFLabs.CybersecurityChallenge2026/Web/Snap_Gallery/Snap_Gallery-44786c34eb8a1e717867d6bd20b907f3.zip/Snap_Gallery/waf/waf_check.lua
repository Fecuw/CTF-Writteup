-- 共通のエラー画面HTML生成関数
local function respond_error(message)
    ngx.status = ngx.HTTP_FORBIDDEN
    ngx.header.content_type = "text/html; charset=UTF-8"
    ngx.say([[
    <!DOCTYPE html>
    <html lang="ja">
    <head>
        <meta charset="UTF-8">
        <title>ページエラー | WAF Alert</title>
        <style>
            body { font-family: 'Helvetica Neue', Arial, sans-serif; background: #f8f9fa; color: #333; padding: 50px; text-align: center; }
            .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border-top: 5px solid #dc3545; }
            h2 { color: #dc3545; margin-top: 0; }
            p { font-size: 16px; line-height: 1.6; color: #666; }
            .btn { display: inline-block; margin-top: 20px; padding: 10px 20px; background: #007bff; color: #fff; text-decoration: none; border-radius: 4px; }
            .btn:hover { background: #0056b3; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>セキュリティ警告 (WAF Blocked)</h2>
            <p>]] .. message .. [[</p>
            <a href="/" class="btn">アップロード画面に戻る</a>
        </div>
    </body>
    </html>
    ]])
    return ngx.exit(ngx.HTTP_FORBIDDEN)
end

-- ボディの読み込みを許可
ngx.req.read_body()

local data = ngx.req.get_body_data()

-- ファイルが大きくてメモリ（get_body_data）に乗らず、一時ファイルにバッファリングされた場合の処理
if not data then
    local file_name = ngx.req.get_body_file()
    if file_name then
        local f = io.open(file_name, "rb")
        if f then
            -- client_max_body_size と同じ上限。これを超えるサイズは検査せず拒否する
            local MAX_INSPECT_BYTES = 10 * 1024 * 1024
            local size = f:seek("end")
            f:seek("set", 0)
            if size and size > MAX_INSPECT_BYTES then
                f:close()
                respond_error("アップロードサイズが大きすぎるため処理を中断しました。")
            end
            data = f:read("*a")
            f:close()
        end
    end
end

-- データが存在する場合のみチェック
if data then
    local lower_data = string.lower(data)

    -- ------------------------------------------------------------------------
    -- アップロードされた内容そのものを検査する
    -- ------------------------------------------------------------------------
    if string.find(lower_data, "<%?php") or string.find(lower_data, "<%?=") then
        respond_error("ファイル内に実行可能なスクリプトコード（PHP）が検出されたため、処理を中断しました。")
    end

    if string.find(lower_data, "<script") and string.find(lower_data, "php") then
        respond_error("ファイル内に実行可能なスクリプトコード（PHP）が検出されたため、処理を中断しました。")
    end
end

-- 何も問題がなければ、リクエストを後ろの php_app へ透過