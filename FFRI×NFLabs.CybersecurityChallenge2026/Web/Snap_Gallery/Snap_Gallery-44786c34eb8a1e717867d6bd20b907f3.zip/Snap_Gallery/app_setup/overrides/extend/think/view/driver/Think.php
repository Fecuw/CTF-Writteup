<?php
// topthink/think-template は think\Template エンジン単体のみを提供し、
// ThinkPHP6 の View ドライバ規約（TemplateHandlerInterface）には
// 対応していないため、両者をつなぐ薄いアダプタを用意する。
namespace think\view\driver;

use think\App;
use think\contract\TemplateHandlerInterface;
use think\Template;

class Think implements TemplateHandlerInterface
{
    protected $app;

    protected $template;

    protected $config = [
        'auto_rule'     => 1,
        'view_dir_name' => 'view',
        'view_path'     => '',
        'view_suffix'   => 'html',
        'view_depr'     => DIRECTORY_SEPARATOR,
        'cache_path'    => '',
        'tpl_begin'     => '{',
        'tpl_end'       => '}',
        'taglib_begin'  => '{',
        'taglib_end'    => '}',
    ];

    public function __construct(App $app, array $config = [])
    {
        $this->app    = $app;
        $this->config = array_merge($this->config, $config);

        if ('' === $this->config['view_path']) {
            $this->config['view_path'] = $this->getViewPath();
        }

        if ('' === $this->config['cache_path']) {
            $this->config['cache_path'] = $app->getRuntimePath() . 'temp' . DIRECTORY_SEPARATOR;
        }

        $this->template = new Template($this->config);
    }

    protected function getViewPath(): string
    {
        $view = $this->config['view_dir_name'];

        if (is_dir($this->app->getAppPath() . $view)) {
            return $this->app->getAppPath() . $view . DIRECTORY_SEPARATOR;
        }

        return $this->app->getRootPath() . $view . DIRECTORY_SEPARATOR;
    }

    public function exists(string $template): bool
    {
        if ('' == pathinfo($template, PATHINFO_EXTENSION)) {
            $tpl      = str_replace(['/', ':'], $this->config['view_depr'], ltrim($template, '/'));
            $template = $this->config['view_path'] . $tpl . '.' . ltrim($this->config['view_suffix'], '.');
        }

        return is_file($template);
    }

    public function fetch(string $template, array $data = []): void
    {
        $this->template->fetch($template, $data);
    }

    public function display(string $content, array $data = []): void
    {
        $this->template->display($content, $data);
    }

    public function config(array $config): void
    {
        $this->config = array_merge($this->config, $config);
    }

    public function getConfig(string $name)
    {
        return $this->config[$name] ?? null;
    }
}
