<?php
namespace app\controller;

use app\BaseController;
use think\facade\Request;

class Upload extends BaseController
{
    // アップロードファイルの保存先
    protected function storagePath()
    {
        return root_path() . 'storage' . DIRECTORY_SEPARATOR . 'topic';
    }

    // 全画面共通のスタイル
    protected function pageStyle()
    {
        return <<<'CSS'
        <style>
            * { box-sizing: border-box; }
            body {
                margin: 0;
                font-family: "Hiragino Maru Gothic ProN", "Yu Gothic", sans-serif;
                background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 45%, #ff9a9e 100%);
                min-height: 100vh;
                color: #4a3f3f;
            }
            .wrap { max-width: 720px; margin: 0 auto; padding: 32px 20px 60px; }
            .logo { text-align: center; font-size: 28px; font-weight: 800; margin-bottom: 4px; }
            .tagline { text-align: center; font-size: 14px; color: #7a6a6a; margin-bottom: 28px; }
            .card {
                background: #fffaf5;
                border-radius: 20px;
                padding: 24px;
                box-shadow: 0 10px 30px rgba(255, 130, 100, 0.18);
                margin-bottom: 28px;
            }
            .card h2 { margin-top: 0; font-size: 18px; }
            .dropzone {
                border: 2px dashed #ffab91;
                border-radius: 14px;
                padding: 24px;
                text-align: center;
                background: #fff3ea;
            }
            .file-picker { display: inline-block; cursor: pointer; margin-bottom: 16px; }
            .file-picker input[type=file] {
                position: absolute;
                width: 1px;
                height: 1px;
                opacity: 0;
                overflow: hidden;
            }
            .file-picker-btn {
                display: inline-block;
                background: #fff;
                border: 2px solid #ffab91;
                color: #ff6f4f;
                padding: 10px 22px;
                border-radius: 999px;
                font-size: 14px;
                font-weight: 700;
                max-width: 260px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                vertical-align: middle;
            }
            button {
                background: linear-gradient(135deg, #ff9a76, #ff6f91);
                color: #fff;
                border: none;
                padding: 10px 28px;
                border-radius: 999px;
                font-size: 15px;
                font-weight: 700;
                cursor: pointer;
                box-shadow: 0 6px 14px rgba(255, 111, 145, 0.4);
            }
            button:hover { opacity: 0.9; }
            .gallery {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                gap: 12px;
            }
            .photo-card {
                display: block;
                text-decoration: none;
                color: inherit;
                background: #fff;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 10px rgba(0,0,0,0.08);
                transition: transform 0.15s ease;
            }
            .photo-card:hover { transform: translateY(-3px); }
            .photo-card .thumb {
                width: 100%;
                aspect-ratio: 1 / 1;
                object-fit: cover;
                display: block;
                background: #ffe8dc;
            }
            .photo-card .cap {
                font-size: 11px;
                padding: 6px 8px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                color: #7a6a6a;
            }
            .empty { text-align: center; color: #a89a9a; padding: 20px 0; }
            .success-card {
                background: #fffaf5;
                border-radius: 20px;
                padding: 40px 24px;
                text-align: center;
                box-shadow: 0 10px 30px rgba(255, 130, 100, 0.18);
            }
            .success-icon { font-size: 48px; margin-bottom: 8px; }
            .success-name { color: #7a6a6a; font-size: 14px; margin-bottom: 20px; word-break: break-all; }
            .back-btn {
                display: inline-block;
                background: linear-gradient(135deg, #ff9a76, #ff6f91);
                color: #fff;
                text-decoration: none;
                padding: 10px 28px;
                border-radius: 999px;
                font-size: 15px;
                font-weight: 700;
                box-shadow: 0 6px 14px rgba(255, 111, 145, 0.4);
            }
            .back-btn:hover { opacity: 0.9; }
        </style>
        CSS;
    }

    // アップロード画面 ＆ ファイル一覧画面
    public function index()
    {
        $storagePath = $this->storagePath();
        $files = [];

        if (is_dir($storagePath)) {
            $scannedFiles = array_diff(scandir($storagePath), array('.', '..'));
            foreach ($scannedFiles as $file) {
                if (is_file($storagePath . DIRECTORY_SEPARATOR . $file)) {
                    $files[] = $file;
                }
            }
        }

        $html = $this->pageStyle() . '
        <div class="wrap">
            <div class="logo">📸 ゆるっとフォト部</div>
            <div class="tagline">今日のお気に入り、シェアしよう</div>

            <div class="card">
                <h2>写真をアップロード</h2>
                <div class="dropzone">
                    <form action="/index.php/upload/upload" method="post" enctype="multipart/form-data">
                        <label class="file-picker">
                            <input type="file" name="image" accept="image/png" onchange="this.nextElementSibling.textContent = this.files[0].name" />
                            <span class="file-picker-btn">📁 写真を選ぶ</span>
                        </label>
                        <br>
                        <button type="submit">アップロードする</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <h2>みんなの写真</h2>';

        if (empty($files)) {
            $html .= '<p class="empty">まだ写真がありません。最初の一枚を投稿してみよう！</p>';
        } else {
            $html .= '<div class="gallery">';
            foreach ($files as $name) {
                // view アクション経由で画像を表示する
                $html .= sprintf(
                    '<a class="photo-card" href="/index.php/upload/view?name=%s" target="_blank">
                        <img class="thumb" src="/index.php/upload/view?name=%s" alt="%s" />
                        <div class="cap">%s</div>
                    </a>',
                    urlencode($name), urlencode($name), htmlspecialchars($name), htmlspecialchars($name)
                );
            }
            $html .= '</div>';
        }

        $html .= '
            </div>
        </div>';

        return $html;
    }

    // アップロード処理（標準の move メソッドを使用）
    public function upload()
    {
        $file = Request::file('image');
        if (null === $file) {
            return response('ファイルが選択されていません', 400);
        }

        try {
            $savePath = $this->storagePath();
            // 元のファイル名で保存する
            $info = $file->move($savePath, $file->getOriginalName());

            if ($info) {
                $html = $this->pageStyle() . sprintf(
                    '<div class="wrap">
                        <div class="success-card">
                            <div class="success-icon">🎉</div>
                            <h2>アップロード成功！</h2>
                            <p class="success-name">保存名: %s</p>
                            <a class="back-btn" href="/">一覧に戻る</a>
                        </div>
                    </div>',
                    htmlspecialchars($info->getFilename())
                );
                return response($html);
            } else {
                return response('ファイルの移動に失敗しました', 500);
            }
        } catch (\Exception $e) {
            return response('エラーが発生しました: ' . $e->getMessage(), 500);
        }
    }

    // アップロード済み画像の表示
    public function view()
    {
        $name = Request::param('name', '');
        $storagePath = $this->storagePath();

        $base   = realpath($storagePath);
        $target = $base ? realpath($base . DIRECTORY_SEPARATOR . $name) : false;

        if (false === $base || false === $target || 0 !== strpos($target, $base . DIRECTORY_SEPARATOR)) {
            return response('Not Found', 404);
        }

        return response(file_get_contents($target))->contentType('image/png');
    }
}
