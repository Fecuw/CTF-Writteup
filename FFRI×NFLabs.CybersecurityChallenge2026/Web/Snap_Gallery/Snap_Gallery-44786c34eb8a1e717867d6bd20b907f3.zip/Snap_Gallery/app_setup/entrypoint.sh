#!/bin/bash
set -e

# 動作用ディレクトリ /app を、起動のたびに次の順で重ねて構築する。
#   1. /src-app            : ThinkPHP の OSS コード（compose.yml で読み取り専用マウント）
#   2. /tmp/tp6_base/vendor: ビルド時に composer で取得した依存パッケージ
#   3. /tmp/app_overrides  : このアプリ固有のコード
echo "Building /app from OSS code, vendor packages and app overrides..."
cp -r /src-app/. /app/
rm -rf /app/vendor
cp -r /tmp/tp6_base/vendor /app/vendor
cp -r /tmp/app_overrides/. /app/
echo "Build complete."

# アップロードされた画像を保存するためのディレクトリを public/ の外に作成する
mkdir -p /app/storage/topic /app/runtime
chmod -R 777 /app/runtime /app/storage

# フラグファイルを、Webから直接参照できない場所に配置する
if [ -z "$FLAG" ]; then
    FLAG='flag{dummy_flag}'
fi
echo "$FLAG" > /flag.txt
chmod 444 /flag.txt

exec "$@"
