# Snap Gallery 起動手順

この問題は Docker Compose で、WAF と ThinkPHP アプリケーションを起動する構成です。初回起動時にアプリケーションが自動的に初期化されます。

## 元になった ThinkPHP OSS コードの取得元

`app/` 配下は、次の公式リポジトリの `v6.0.12` タグ時点の内容と同一です。

- リポジトリ: <https://github.com/top-think/think/tree/v6.0.12>
- composer での取得:

  ```bash
  composer create-project topthink/think=6.0.12 think-oss
  ```

## 前提条件

- Docker
- Docker Compose

## 1. ディレクトリ移動

`compose.yml` は、この `README.md` と同じディレクトリにあります。`docker compose` コマンドはカレントディレクトリの `compose.yml` を探すため、このディレクトリに移動してから実行してください。

`ls compose.yml` を実行して、`compose.yml` ファイルが存在することを確認してください。もしも異なるディレクトリである場合は、`docker compose up` コマンドの実行時に `no configuration file provided: not found` のようなエラーが発生します。

## 2. コンテナを起動

```bash
docker compose up -d --build
```

初回起動時に、ThinkPHP のテンプレートが自動で初期化され、アップロード保存用ディレクトリも作成されます。起動に少し時間がかかる場合があります。

## 3. アクセス

次の URL へアクセスすると、WAF を経由してアプリケーションにアクセスできます。

- http://localhost:22200/

## 4. ログ確認

必要な場合、次のコマンドでログを確認します。

```bash
docker compose logs -f
```

## 5. 停止

次のコマンドで、アプリケーションを停止します。

```bash
docker compose down
```

## 6. 再起動

変更後に再起動する場合は、次のコマンドを実行してください。

```bash
docker compose down
docker compose up -d --build
```
