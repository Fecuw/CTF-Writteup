# 動作検証手順

1. `docker compose up --build` を実行して、Dockerイメージのビルドや、Dockerコンテナの実行を行います。
    - このとき`compose.yml`の内容により、ホストの`22001/tcp`がDockerコンテナの`80/tcp`と紐づけられます。
2. `http[:]//localhost:22001` というURLにアクセスし問題へ挑みます。