from functools import wraps

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    session,
    url_for,
)

auth_bp = Blueprint("auth", __name__)


USERS = {
    "guest": {
        "password": "guest",
        "role": "user",
    }
}


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    username = request.form.get("username", "")
    password = request.form.get("password", "")

    user = USERS.get(username)

    if user is None or user["password"] != password:
        return render_template(
            "login.html",
            error="Invalid username or password."
        )

    session.clear()

    session["username"] = username
    session["role"] = user["role"]

    return redirect(url_for("index"))


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if "username" not in session:
            return redirect(url_for("auth.login"))

        return func(*args, **kwargs)

    return wrapper


def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            return "403 Forbidden", 403

        return func(*args, **kwargs)

    return wrapper