from datetime import datetime
import os

def load_secret_key():
    key_path = os.path.join(
        os.path.dirname(__file__),
        "secret.key"
    )

    with open(key_path, "r") as f:
        return f.read().strip()

POSTS = [
    {
        "id": 0,
        "title": "Welcome!",
        "author": "teacher",
        "date": "2026-07-01",
        "content": """
Welcome to our school blog!

This site is used to share school events and announcements.
Please enjoy reading our posts!
""",
    },
    {
    "id": 1,
    "title": "Cyber Security Challenge 2026",
    "author": "student",
    "date": "2026-07-08",
    "content": """
The Cyber Security Challenge will be held this autumn.

Students will compete in several CTF categories:
Web, Crypto, Reverse Engineering, Pwn, and Penetration Testing.

Whether you are a beginner or an experienced player,
everyone is welcome to join and learn new security techniques.

Let's explore the world of cybersecurity and become better hackers
together!

Registration will open soon. We look forward to seeing you at the event.
""",
},
    {
        "id": 2,
        "title": "Blog Update",
        "author": "teacher",
        "date": "2026-07-10",
        "content": """
The blog system has been updated.

A new preview feature has been added for administrators.
""",
    },
]


def get_post(post_id: int):
    """Return a post by its ID."""

    for post in POSTS:
        if post["id"] == post_id:
            return post

    return None


def get_latest_posts():
    """Return posts sorted by ID (newest first)."""

    return sorted(
        POSTS,
        key=lambda x: x["id"],
        reverse=True,
    )


def current_time():
    """Return current server time."""

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")