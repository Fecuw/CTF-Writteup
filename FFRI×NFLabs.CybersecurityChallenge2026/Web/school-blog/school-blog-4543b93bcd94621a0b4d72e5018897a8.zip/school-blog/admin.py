from flask import (
    Blueprint,
    render_template,
    request,
    session,
)
from flask import render_template_string

from auth import admin_required

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/admin")
@admin_required
def admin():
    return render_template(
        "admin.html",
        draft=session.get("draft", "")
    )


@admin_bp.route("/admin/save", methods=["POST"])
@admin_required
def save():

    draft = request.form.get("draft", "")

    session["draft"] = draft

    return render_template(
        "admin.html",
        draft=draft,
        message="Saved!"
    )


@admin_bp.route("/admin/preview")
@admin_required
def preview():

    draft = session.get(
        "draft",
        "<h2>No Draft</h2>"
    )

    return render_template_string(
        draft,
        title="Preview"
    )