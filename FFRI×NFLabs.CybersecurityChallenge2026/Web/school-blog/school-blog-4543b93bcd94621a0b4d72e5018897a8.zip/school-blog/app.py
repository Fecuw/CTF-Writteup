from flask import Flask, render_template, request
from auth import auth_bp
from admin import admin_bp
from utils import POSTS, load_secret_key

app = Flask(__name__)

app.config["SECRET_KEY"] = load_secret_key()

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)


@app.route("/")
def index():
    return render_template("index.html", posts=POSTS)


@app.route("/post/<int:post_id>")
def post(post_id):
    if post_id >= len(POSTS):
        return "Not Found", 404

    return render_template(
        "post.html",
        post=POSTS[post_id]
    )


@app.route("/about")
def about():
    msg = request.args.get(
        "msg",
        "Welcome to our school blog!"
    )

    try:
        message = msg.format(
            config=app.config,
            version="1.0.0"
        )
    except Exception:
        message = "Formatting Error"

    return render_template(
        "about.html",
        message=message
    )


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=22521,
        debug=False
    )