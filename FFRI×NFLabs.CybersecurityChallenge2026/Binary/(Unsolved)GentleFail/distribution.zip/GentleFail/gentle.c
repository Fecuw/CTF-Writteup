#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/device.h>
#include <linux/miscdevice.h>
#include <linux/scatterlist.h>
#include <linux/file.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <linux/pagemap.h>

MODULE_AUTHOR(":sob:");
MODULE_DESCRIPTION("GentleFail");
MODULE_LICENSE("GPL");

#define DEVICE_NAME "gentle"

#define CMD_SENDMSG 0x1008
#define CMD_SPLICE 0x1009
#define CMD_RECVMSG 0x100a
#define MAX_SG 10
#define AAD_MAX 64
#define AAD_MIN 8
#define OUTBUF_SZ 8192
#define SCRATCHPAD_SZ 256

struct sess {
	struct scatterlist tx[MAX_SG];
	int tx_n;
	void *kbufs[MAX_SG];
	int kb_n;

	struct page* pc_pages[MAX_SG];
	int pc_n;

	void *outbuf;
	__u32 outbuf_sz;
};

struct aead_req {
	__u32 assoclen;
	__u32 cryptlen;
	__u32 authsize;
	__u64 rx_buf;
	__u32 rx_len;
};

struct splice_req {
	__s32 fd;
	__u32 len;
	__u64 offset;
};

struct sendmsg_req {
	__u64 aad;
	__u32 aad_len;
};


static int tx_read(struct sess *s, unsigned int off, void *buf, unsigned int len) {
	unsigned int done = 0;
	int i;

	for (i = 0; i < s->tx_n && len; i++) {
		struct scatterlist *sg = &s->tx[i];
		unsigned int seg = sg->length, in_seg, n;
		void *kaddr;

		if (off >= seg) {
			off -= seg;
			continue;
		}
		in_seg = seg - off;
		n      = min(in_seg, len);
		kaddr  = kmap_local_page(sg_page(sg));
		memcpy((char *)buf + done, kaddr + sg->offset + off, n);
		kunmap_local(kaddr);
		done += n;
		len  -= n;
		off   = 0;
	}
	return len ? -EINVAL : 0;
}

static int tx_tag(struct sess *s, unsigned int tag_start, struct scatterlist *tag) {
	unsigned int off = tag_start;
	int i;

	for (i = 0; i < s->tx_n; i++) {
		struct scatterlist *sg = &s->tx[i];
		unsigned int seg = sg->length;

		if (off >= seg) {
			off -= seg;
			continue;
		}
		sg_init_table(tag, 1);
		sg_set_page(&tag[0], sg_page(sg), seg - off, sg->offset + off);
		return (int)(seg - off);
	}
	return -EINVAL;
}

static int sgl_copy(struct scatterlist *sgl, unsigned int off, void *buf, unsigned int len, int to_sgl) {
	struct scatterlist *sg;
	unsigned int done = 0;

	for (sg = sgl; sg && len; sg = sg_next(sg)) { 
		unsigned int seg = sg->length, in_seg, n;
		struct page *pg;
		void *kaddr, *p;

		if (off >= seg) {
			off -= seg;
			continue;
		}
		in_seg = seg - off;
		n      = min(in_seg, len);
		pg     = sg_page(sg);

		kaddr = kmap_local_page(pg);
		p     = kaddr + sg->offset + off;
		if (to_sgl)
			memcpy(p, (char *)buf + done, n); 
		else
			memcpy((char *)buf + done, p, n);
		kunmap_local(kaddr);

		done += n;
		len  -= n;
		off   = 0;
	}
	return len ? -EINVAL : 0;
}


static long op_sendmsg(struct sess* s, void __user* u) {
	struct sendmsg_req r;
	void *buf;

	if (copy_from_user(&r, u, sizeof(r)))
		return -EINVAL;
	if (r.aad_len < AAD_MIN || r.aad_len > AAD_MAX)
		return -EINVAL;

	if (s->tx_n >= MAX_SG)
		return -EINVAL;

	if (!(buf = kmalloc(r.aad_len, GFP_KERNEL)))
		return -ENOMEM;
	if (copy_from_user(buf, (void __user *)r.aad, r.aad_len)) {
		kfree(buf);
		return -EINVAL;
	}

	sg_set_buf(&s->tx[s->tx_n++], buf, r.aad_len);
	s->kbufs[s->kb_n++] = buf;

	return 0;
}


static long op_splice(struct sess* s, void __user* u) {
	struct splice_req r;
	struct file* file;
	struct page *page;
	pgoff_t index;
	u32 in_page, len;

	if (copy_from_user(&r, u, sizeof(r)))
		return -EINVAL;

	if (s->tx_n >= MAX_SG)
		return -EINVAL;

	file = fget(r.fd);
	if (!file)
		return -EBADF;

	index = (pgoff_t)(r.offset >> PAGE_SHIFT);
	in_page = (u32)(r.offset & ~PAGE_MASK);

	page = find_get_page(file->f_mapping, index);
	fput(file);
	if (!page)
		return -EINVAL;

	len = min_t(u32, r.len, (u32)(PAGE_SIZE - in_page));
	if (len == 0) {
		put_page(page);
		return -EINVAL;
	}

	
	if (s->tx_n + 1 >= MAX_SG) {
		put_page(page);
		return -EINVAL;
	}

	
	{
		void *sp = kzalloc(SCRATCHPAD_SZ, GFP_KERNEL);
		if (!sp) {
			put_page(page);
			return -ENOMEM;
		}
		sg_set_buf(&s->tx[s->tx_n++], sp, SCRATCHPAD_SZ);
		s->kbufs[s->kb_n++] = sp;
	}

	sg_set_page(&s->tx[s->tx_n], page, len, in_page);
	s->pc_pages[s->pc_n++] = page;
	s->tx_n++;
	return 0;
}

static long op_recvmsg(struct sess *s, void __user *arg)
{
	struct aead_req r;
	struct scatterlist dst[2];      
	struct scatterlist tag[1];      
	void __user *rx_buf;
	u32 out_len, scratch_off, in_tag;
	u32 seqno_lo;
	int avail, ret;

	if (copy_from_user(&r, arg, sizeof(r)))
		return -EFAULT;
	if (s->tx_n == 0)
		return -EINVAL;

	rx_buf = (void __user *)(unsigned long)r.rx_buf;


	if ((u64)r.assoclen + r.cryptlen < r.authsize)
		return -EINVAL;
	out_len = r.assoclen + r.cryptlen - r.authsize;
	if (out_len < 1 || out_len > s->outbuf_sz)
		return -EINVAL;             

	ret = tx_read(s, 0, s->outbuf, out_len);
	if (ret)
		return ret;                 
	if (rx_buf && r.rx_len >= out_len)
		if(copy_to_user(rx_buf, s->outbuf, out_len))
			return -EINVAL;

	avail = tx_tag(s, out_len, tag);
	if (avail < 0)
		return avail;               

	scratch_off = r.assoclen + r.cryptlen;
	in_tag      = scratch_off - out_len;        
	if ((u64)in_tag + 4 > (u32)avail)
		return -EINVAL;

	sg_init_table(dst, 2);
	sg_set_buf(&dst[0], s->outbuf, out_len);
	sg_chain(dst, 2, tag);

	memcpy(&seqno_lo, (char *)s->outbuf + 4, 4);

	ret = sgl_copy(dst, scratch_off, &seqno_lo, 4, 1);
	if (ret)
		return ret;

	return -EBADMSG;
}




static int module_open(struct inode *inode, struct file *filp) {
	printk("gentle opened.");

	struct sess *s = kzalloc(sizeof(struct sess), GFP_KERNEL);
	if (!s)
		return -ENOMEM;
	sg_init_table(s->tx, MAX_SG);

	s->outbuf = kzalloc(OUTBUF_SZ, GFP_KERNEL);
	if (!s->outbuf) {
		kfree(s);
		return -ENOMEM;
	}
	s->outbuf_sz = OUTBUF_SZ;

	filp->private_data = s;

	return 0;
}


static int module_release(struct inode *inode, struct file *filp) {
	struct sess *s = filp->private_data;
	int i;

	for (i = 0; i < s->pc_n; i++)
		put_page(s->pc_pages[i]);       
	for (i = 0; i < s->kb_n; i++)
		kfree(s->kbufs[i]);             
	kfree(s->outbuf);
	kfree(s);
	return 0;
}


static long module_ioctl(struct file *filp, unsigned int cmd , unsigned long arg) {
	struct sess* s = filp->private_data;
	switch (cmd) {
		case CMD_SENDMSG:
			return op_sendmsg(s, (void*)arg);
		case CMD_SPLICE:
			return op_splice(s, (void*)arg);
		case CMD_RECVMSG:
			return op_recvmsg(s, (void*)arg);
	} 
	return 0;
}


static struct file_operations module_fops = {
	.owner = THIS_MODULE,
	.open = module_open,
	.release = module_release, 
	.unlocked_ioctl = module_ioctl
};

static struct miscdevice device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = DEVICE_NAME,
	.fops = &module_fops,
	.mode = 0666
};

static int __init module_initialize(void)
{
	misc_register(&device);

	return 0;
}

static void __exit module_cleanup(void)
{
	misc_deregister(&device);
}

module_init(module_initialize);
module_exit(module_cleanup);
