#!/bin/sh
exec qemu-system-x86_64 \
    -nic none -nographic -serial mon:stdio \
    -m 256M -smp 1 \
    -kernel bzImage \
    -append "console=ttyS0 loglevel=3 oops=panic panic=-1 pti=on nokaslr" \
    -no-reboot -cpu qemu64,+smap,+smep \
    -initrd rootfs.cpio
