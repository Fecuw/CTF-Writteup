#define _GNU_SOURCE
#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 4
#define MAX_LEN 48

char buf[MAX_LEN];

int read_db(char *db_path, char data[MAX_LINES][MAX_LEN], size_t *nof_names) {
    FILE *fp = fopen(db_path, "rb");
    if (fp == NULL) {
        return 0;
    }
    memset(buf, 0, MAX_LEN);

    size_t i;
    for (i = 0; fread(buf, sizeof(char), MAX_LEN, fp); i++) {
        memcpy(data[i], buf, MAX_LEN);
    }

    fclose(fp);

    *nof_names = i;
    return 1;
}

int write_db(char *db_path, char *new_name) {
    FILE *fp = fopen(db_path, "a+b");
    if (fp == NULL) {
        return 0;
    }
    fwrite(new_name, sizeof(char), MAX_LEN, fp);
    fclose(fp);

    return 1;
}

int is_regex_match(const char *pattern, const char *subject) {
    pcre2_code *regex = NULL;
    pcre2_match_data *match_data = NULL;
    int error_code;
    PCRE2_SIZE error_offset;
    int match_result;
    int result = 0;

    if (pattern == NULL || subject == NULL) {
        return 0;
    }

    regex = pcre2_compile(
            (PCRE2_SPTR) pattern,
            PCRE2_ZERO_TERMINATED,
            0,
            &error_code,
            &error_offset,
            NULL);

    if (regex == NULL) {
        return 0;
    }

    match_data = pcre2_match_data_create_from_pattern(regex, NULL);
    if (match_data == NULL) {
        pcre2_code_free(regex);
        return 0;
    }

    pcre2_match_context *mctx = pcre2_match_context_create(NULL);
    if (mctx == NULL) {
        pcre2_match_data_free(match_data);
        pcre2_code_free(regex);
        return 0;
    }

    pcre2_set_match_limit(mctx, 1024 * 1024 * 1024);
    match_result = pcre2_match(
            regex,
            (PCRE2_SPTR) subject,
            strlen(subject),
            0,
            0,
            match_data,
            mctx);

    if (match_result >= 0) {
        result = 1;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(regex);
    pcre2_match_context_free(mctx);

    return result;
}

int cmd_get(char *db_path) {
    char names[MAX_LINES][MAX_LEN] = {0};
    size_t nof_names = 0;

    if (!read_db(db_path, names, &nof_names)) {
        printf("Couldn't read %s.\n", db_path);
        return 3;
    }

    for (size_t i = 0; i < nof_names; i++) {
        printf("%s\n", names[i]);
    }

    return 0;
}

int cmd_set(char *db_path, char *new_name_path) {
    char names[MAX_LINES][MAX_LEN] = {0};
    char new_name[MAX_LEN] = {0};
    size_t nof_names = 0;

    if (!read_db(db_path, names, &nof_names)) {
        printf("Couldn't read %s.\n", db_path);
        return 3;
    }

    if (nof_names >= MAX_LINES) {
        printf("Too many names.\n");
        return 5;
    }

    FILE *fp = fopen(new_name_path, "rb");
    if (fp == NULL) {
        printf("Couldn't open %s.\n", new_name_path);
        return 7;
    }

    if (!fread(new_name, sizeof(char), MAX_LEN, fp)) {
        printf("Couldn't read %s.\n", new_name_path);
        fclose(fp);
        return 8;
    }
    fclose(fp);

    if (new_name[MAX_LEN - 1] != '\0') {
        printf("Name is too long.\n");
        return 9;
    }

    // なんか a だけの名前を大量に書き込むボットが出てきたから a だけの名前は禁止！😠😡👹😡😠😡👹😡😠😡👹😡😠😡👹😡😠😡👹
    if (is_regex_match("^(a+)+$", new_name)) {
        printf("No 'a'-only names allowed!\n");
        return 6;
    }

    if (!write_db(db_path, new_name)) {
        printf("Couldn't write %s.\n", db_path);
        return 4;
    }

    printf("Name added successfully.\n");

    return 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("%s <command>\n", argv[0]);
        return 1;
    }

    if (!strcmp(argv[1], "get")) {
        if (argc < 3) {
            printf("%s get <db file>\n", argv[0]);
            return 2;
        }
        return cmd_get(argv[2]);
    }
    if (!strcmp(argv[1], "set")) {
        if (argc < 4) {
            printf("%s set <db file> <new name file>\n", argv[0]);
            return 2;
        }
        return cmd_set(argv[2], argv[3]);
    }

    printf("Unknown command: %s\n", argv[1]);
    exit(1);
}
