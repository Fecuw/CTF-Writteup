#!/usr/bin/env bash

# Build script for Ubuntu
sudo apt update
sudo apt install clang cmake pkg-config libpcre2-dev
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
