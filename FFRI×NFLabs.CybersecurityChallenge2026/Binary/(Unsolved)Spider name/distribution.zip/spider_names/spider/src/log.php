<?php
declare(strict_types=1);

header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header(
        "Content-Security-Policy: "
        . "default-src 'none'; "
        . "style-src 'unsafe-inline'; "
        . "form-action 'self'; "
        . "base-uri 'none'"
);

const DB_NAME = '/names.db';

function runFfrdb(array $arguments): array
{
    $command = array_merge(['/ffrdb'], $arguments);

    $descriptorSpec = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['file', '/dev/null', 'a'],
    ];

    $process = proc_open(
            $command,
            $descriptorSpec,
            $pipes,
            '/'
    );

    if (!is_resource($process)) {
        return [
                'exitCode' => -1,
                'stdout' => '',
        ];
    }

    fclose($pipes[0]);

    $stdout = stream_get_contents($pipes[1]);
    fclose($pipes[1]);

    $exitCode = proc_close($process);

    return [
            'exitCode' => $exitCode,
            'stdout' => $stdout === false ? '' : $stdout,
    ];
}

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

function clearDatabase(): bool
{
    $file = @fopen(DB_NAME, 'c+b');

    if ($file === false) return false;


    try {
        if (!flock($file, LOCK_EX)) return false;
        if (!ftruncate($file, 0)) return false;

        rewind($file);

        return fflush($file);
    } finally {
        flock($file, LOCK_UN);
        fclose($file);
    }
}

$cmd = $_GET['cmd'] ?? 'get';
$message = null;
$messageIsError = false;

function handleSet()
{
    global $message, $messageIsError;
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        echo '<p>The set command requires a POST request.</p>';
        exit;
    }

    $name = $_POST['name'] ?? null;
    if ($name === null) {
        http_response_code(400);
        echo '<p>The name field is missing.</p>';
        exit;
    }

    $nameFile = tmpfile();

    if ($nameFile === false) {
        http_response_code(500);
        echo '<p>Failed to create a temporary name file.</p>';
        exit;
    }

    try {
        $metadata = stream_get_meta_data($nameFile);
        $nameFilePath = $metadata['uri'] ?? null;

        if (!is_string($nameFilePath)) {
            http_response_code(500);
            echo '<p>Failed to obtain the temporary name file path.</p>';
            exit;
        }

        $nameLength = strlen($name);
        if ($nameLength > 48) {
            http_response_code(400);
            echo '<p>Name is too long.</p>';
            exit;
        }

        $written = fwrite($nameFile, $name);

        if ($written === false || $written === 0) {
            http_response_code(500);
            echo '<p>Failed to write the name to the temporary file.</p>';
            exit;
        }

        if (!fflush($nameFile)) {
            http_response_code(500);
            echo '<p>Failed to write name to file.</p>';
            exit;
        }

        $result = runFfrdb(['set', DB_NAME, $nameFilePath]);

        if ($result['exitCode'] === 0) {
            $message = '名前の追加に成功しました。';
        } else {
            http_response_code(400);
            $message = '名前の追加に失敗しました。エラー値: ' . $result['exitCode'];
            $messageIsError = true;
        }
    } catch (Throwable $error) {
        http_response_code(400);
        $message = '名前の追加に失敗しました。';
        $messageIsError = true;
    } finally {
        fclose($nameFile);
    }
}

function handleClear()
{
    global $message, $messageIsError;

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        echo '<p>The cls command requires a POST request.</p>';
        exit;
    }

    if (clearDatabase()) {
        $message = 'ログを削除しました。';
        echo '<p>ログを削除しました</p>';
        exit;
    } else {
        http_response_code(500);
        $message = 'ログの削除に失敗しました。';
        $messageIsError = true;
    }
}

$getError = null;
$names = [];

function handleGet()
{
    global $getError, $names;

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        header('Allow: GET');
        echo '<p>The get command requires a GET request.</p>';
        exit;
    }
    $result = runFfrdb(['get', DB_NAME]);
    $getError = null;
    $names = [];

    if ($result['exitCode'] !== 0) {
        http_response_code(500);
        $getError = 'ログの取得に失敗しました。エラー値: ' . $result['exitCode'];
    } else {
        $lines = preg_split('/\r\n|\r|\n/', $result['stdout']);

        if ($lines !== false) {
            $names = $lines;

            while ($names !== [] && end($names) === '') {
                array_pop($names);
            }
        }
    }
}

if (!is_string($cmd)) {
    http_response_code(400);
    echo '<p>Invalid command.</p>';
    exit;
}

switch ($cmd) {
    case 'get':
        handleGet();
        break;
    case 'set':
        handleSet();
        break;
    case 'cls':
        handleClear();
        break;
    default:
        http_response_code(400);
        echo '<p>Invalid command.</p>';
        exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ログ一覧</title>
    <style>
        body {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 16px;
            font-family: sans-serif;
        }

        .message {
            padding: 12px;
            border: 1px solid #2e7d32;
            background: #e8f5e9;
        }

        .error {
            border-color: #c62828;
            background: #ffebee;
        }

        table {
            width: 100%;
            margin-top: 16px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }

        form {
            margin-top: 16px;
        }
    </style>
</head>
<body>
<h1>ログ一覧</h1>

<?php if ($message !== null): ?>
    <p class="message<?= $messageIsError ? ' error' : '' ?>">
        <?= escapeHtml($message) ?>
    </p>
<?php endif; ?>

<?php if ($cmd === 'get'): ?>
    <?php if ($getError !== null): ?>
        <p class="message error"><?= escapeHtml($getError) ?></p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Name</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($names === []): ?>
                <tr>
                    <td>データがありません。</td>
                </tr>
            <?php else: ?>
                <?php foreach ($names as $name): ?>
                    <tr>
                        <td><?= escapeHtml($name) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php endif; ?>

<h2>名前を追加</h2>

<form method="post" action="/log.php?cmd=set">
    <label>
        Name:
        <input
                type="text"
                name="name"
                maxlength="48"
                required
        >
    </label>
    <button type="submit">追加</button>
</form>

<h2>ログを削除</h2>

<form method="post" action="/log.php?cmd=cls">
    <button type="submit">すべて削除</button>
</form>

<p><a href="/">トップへ戻る</a></p>
</body>
</html>
