<?php
declare(strict_types=1);
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spider names</title>
</head>
<body>
    <h1>Spider names</h1>

    <a href="/log.php">名前ログを見る</a>
</body>
</html>
