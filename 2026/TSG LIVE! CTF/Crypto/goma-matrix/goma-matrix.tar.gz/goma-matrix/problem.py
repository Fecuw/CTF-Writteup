import json
from math import gcd

from Crypto.Util.number import getPrime


def mat_modmul(A, B, N):
    return [
        [sum(A[i][k] * B[k][j] for k in range(2)) % N for j in range(2)]
        for i in range(2)
    ]


def mat_modpow(A, exponent, N):
    assert exponent >= 0
    result = [[1, 0], [0, 1]]
    while exponent:
        if exponent & 1:
            result = mat_modmul(result, A, N)
        A = mat_modmul(A, A, N)
        exponent >>= 1
    return result


e = 65537
while True:
    p, q = getPrime(1024), getPrime(1024)
    if p != q and gcd(e, (p - 1) * (q - 1)) == 1:
        break

N = p * q
with open("flag.txt", "rb") as f:
    m = int.from_bytes(f.read(), "big")

assert 0 < m < N
assert gcd(m, N) == 1
assert gcd(e, N) == 1

M = [[m, 1], [0, m]]
C = mat_modpow(M, e, N)
print(json.dumps({"N": N, "e": e, "C": C}, indent=2))
