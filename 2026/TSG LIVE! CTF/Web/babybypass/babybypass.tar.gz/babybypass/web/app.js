
const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const crypto = require("crypto");

const app = express();

app.use(express.urlencoded({ extended: false }));

const FLAG = process.env.FLAG || "TSGLIVE{DUMMY_FLAG}";

const db = new sqlite3.Database("database.db");

app.get("/", (req, res) => {
    res.send(`
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://unpkg.com/sakura.css/css/sakura.css" type="text/css" />
</head>
<body>
  <main>
    <h1> babybypass 👶 </h1>
    <p>login as admin to get the flag!</p>
    <form id="login-form">
      <label for="username">Username</label>
      <input name="username" placeholder="admin" required>
      <label for="password">Password</label>
      <input name="password" placeholder="" required>
      <button type="submit" id="login-btn">Login</button>
    </form>
    <h6>Response:</h6>
    <pre><code id="code"></code></pre>
  </main>
  <script>
    document.getElementById("login-form").onsubmit = async (e) => {
      e.preventDefault();
      const form = e.target;
      const formData = new URLSearchParams(new FormData(form));
    const response = await fetch("/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: formData,
    });
      const text = await response.text();
      document.getElementById("code").textContent = text;
    };
  </script>
</body>`);
});

app.post("/login", (req, res) => {
    const username = req.body.username || "";
    const password = req.body.password || "";

    if (
        typeof username !== "string" ||
        typeof password !== "string"
    ) {
        return res.send("Invalid input");
    }

    // I removed quotes, so it must be safe!
    const query =
        `SELECT * FROM users WHERE username='${username.replace("'", "")}' AND password='${password.replace("'", "")}';`;

    db.get(query, (err, user) => {
        if (err) {
            return res.send(`SQL error: ${err.message}`);
        }

        if (!user) {
            return res.send("invalid credentials");
        }

        if (user.username === "admin") {
            return res.send(`Hello, admin! Here is your flag: ${FLAG}`);
        }

        return res.send(`Hello, ${user.username}!`);
    });
});

function initDB() {
    db.serialize(() => {
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL
            )
        `);

        const password = crypto.createHash("sha256").update(FLAG).digest("hex");

        db.run(
            "INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)",
            ["admin", password]
        );
    });
}

initDB();

app.listen(3000, "0.0.0.0", () => {
    console.log("Server listening on port 3000");
});
