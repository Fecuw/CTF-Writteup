const express = require('express');
const { execFile } = require("child_process");
const app = express();


app.get("/", (req, res) => {
    res.redirect("/file?filename=index.html");
});

app.get("/file", (req, res) => {
    const filename = req.query.filename || "index.html";
    if (typeof filename !== "string") {
        return res.send("Invalid filename");
    }

    if (filename.includes("..") || filename.includes("%") || filename.includes("flag")) {
        return res.send("No path traversal!");
    }

    const file = `file://${process.cwd()}/public/${filename}`;

    execFile(
        "curl",
        [file],
        { timeout: 1000, maxBuffer: 10 * 1024 * 1024 },
        (error, stdout) => {
            if (error) {
                if (error.killed) {
                    return res.send("Timeout");
                }
                return res.send("Something wrong");
            }

            const result = stdout.replace(/TSGLIVE\{.+\}/, "TSGLIVE{*** REDACTED ***}");
            return res.send(result);
        }
    );
});

app.listen(3000, () => {
    console.log('Server listening on port 3000');
});