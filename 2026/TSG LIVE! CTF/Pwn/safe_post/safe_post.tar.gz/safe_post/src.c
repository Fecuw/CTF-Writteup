// gcc -O2 -U_FORTIFY_SOURCE -fno-stack-protector -no-pie -o chal src.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct msg {
    char title[16];
    size_t size;
    char body[];
};

char input[256];


// Refuse anything larger than the destination
#define SAFE_COPY(dst, src, n)                          \
    do {                                                \
        if ((n) > __builtin_object_size((dst), 1)) {    \
            puts("too long!");                          \
            return;                                     \
        }                                               \
        memcpy((dst), (src), (n));                      \
    } while (0)


void win(void) {
    char *argv[] = {"/bin/sh", NULL};
    execve(argv[0], argv, NULL);
}

size_t read_input(const char *prompt) {
    printf("%s", prompt);
    if (fgets(input, sizeof(input), stdin) == NULL)
        exit(0);
    size_t n = strcspn(input, "\n");
    input[n] = '\0';
    return n;
}

void post(void) {
    read_input("body size> ");
    size_t size = strtoul(input, NULL, 10);
    if (size < 1 || size > 64) {
        puts("invalid size");
        return;
    }

    char storage[sizeof(struct msg) + size];   // header + body on the stack
    struct msg *m = (struct msg *)storage;
    m->size = size;

    size_t tlen = read_input("title> ");
    SAFE_COPY(m->title, input, tlen);
    size_t blen = read_input("body> ");
    SAFE_COPY(m->body, input, blen);

    printf("posted: [%.*s] %.*s\n", (int)tlen, m->title, (int)blen, m->body);
}

int main(void) {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
    
    post();
    puts("bye");
    return 0;
}
